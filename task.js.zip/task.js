class Task {
    
    constructor(important, title, dueDate, contact, location, desc, color) {
        this.important = important;
        this.title = title;
        this.dueDate = dueDate;
        this.contact = contact;
        this.location = location;
        this.description = desc;
        this.color = color;

        this.name = "Nandoch26";
        

    }
}